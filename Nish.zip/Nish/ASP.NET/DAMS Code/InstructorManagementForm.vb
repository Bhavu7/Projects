' Instructor Management Form (InstructorManagementForm.vb)
Imports System.Data.SqlClient

Public Class InstructorManagementForm
    Private connectionString As String = "Server=YOUR_SERVER_NAME;Database=DanceAcademyDB;Integrated Security=True;"

    Private Sub InstructorManagementForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadInstructors()
    End Sub

    Private Sub LoadInstructors()
        Using conn As New SqlConnection(connectionString)
            Dim query As String = "SELECT * FROM InsInfo"
            Dim adapter As New SqlDataAdapter(query, conn)
            Dim table As New DataTable()

            adapter.Fill(table)
            DataGridViewInstructors.DataSource = table
        End Using
    End Sub

    Private Sub BtnAddInstructor_Click(sender As Object, e As EventArgs) Handles BtnAddInstructor.Click
        Using conn As New SqlConnection(connectionString)
            Dim query As String = "INSERT INTO InsInfo (Ins_id, Insfname, Inslname, Cont_no, Email, Address, Gender, Age, Specialize, Avalbillity) VALUES (@Ins_id, @Insfname, @Inslname, @Cont_no, @Email, @Address, @Gender, @Age, @Specialize, @Avalbillity)"
            Dim cmd As New SqlCommand(query, conn)

            cmd.Parameters.AddWithValue("@Ins_id", TxtInstructorID.Text)
            cmd.Parameters.AddWithValue("@Insfname", TxtFirstName.Text)
            cmd.Parameters.AddWithValue("@Inslname", TxtLastName.Text)
            cmd.Parameters.AddWithValue("@Cont_no", TxtContact.Text)
            cmd.Parameters.AddWithValue("@Email", TxtEmail.Text)
            cmd.Parameters.AddWithValue("@Address", TxtAddress.Text)
            cmd.Parameters.AddWithValue("@Gender", CmbGender.SelectedItem.ToString())
            cmd.Parameters.AddWithValue("@Age", TxtAge.Text)
            cmd.Parameters.AddWithValue("@Specialize", TxtSpecialize.Text)
            cmd.Parameters.AddWithValue("@Avalbillity", TxtAvailability.Text)

            conn.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Instructor added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LoadInstructors()
        End Using
    End Sub

    Private Sub BtnDeleteInstructor_Click(sender As Object, e As EventArgs) Handles BtnDeleteInstructor.Click
        If DataGridViewInstructors.SelectedRows.Count > 0 Then
            Dim instructorID As String = DataGridViewInstructors.SelectedRows(0).Cells("Ins_id").Value.ToString()

            Using conn As New SqlConnection(connectionString)
                Dim query As String = "DELETE FROM InsInfo WHERE Ins_id = @Ins_id"
                Dim cmd As New SqlCommand(query, conn)

                cmd.Parameters.AddWithValue("@Ins_id", instructorID)

                conn.Open()
                cmd.ExecuteNonQuery()
                MessageBox.Show("Instructor deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LoadInstructors()
            End Using
        Else
            MessageBox.Show("Please select an instructor to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub BtnUpdateInstructor_Click(sender As Object, e As EventArgs) Handles BtnUpdateInstructor.Click
        If DataGridViewInstructors.SelectedRows.Count > 0 Then
            Dim instructorID As String = DataGridViewInstructors.SelectedRows(0).Cells("Ins_id").Value.ToString()

            Using conn As New SqlConnection(connectionString)
                Dim query As String = "UPDATE InsInfo SET Insfname = @Insfname, Inslname = @Inslname, Cont_no = @Cont_no, Email = @Email, Address = @Address, Gender = @Gender, Age = @Age, Specialize = @Specialize, Avalbillity = @Avalbillity WHERE Ins_id = @Ins_id"
                Dim cmd As New SqlCommand(query, conn)

                cmd.Parameters.AddWithValue("@Ins_id", instructorID)
                cmd.Parameters.AddWithValue("@Insfname", TxtFirstName.Text)
                cmd.Parameters.AddWithValue("@Inslname", TxtLastName.Text)
                cmd.Parameters.AddWithValue("@Cont_no", TxtContact.Text)
                cmd.Parameters.AddWithValue("@Email", TxtEmail.Text)
                cmd.Parameters.AddWithValue("@Address", TxtAddress.Text)
                cmd.Parameters.AddWithValue("@Gender", CmbGender.SelectedItem.ToString())
                cmd.Parameters.AddWithValue("@Age", TxtAge.Text)
                cmd.Parameters.AddWithValue("@Specialize", TxtSpecialize.Text)
                cmd.Parameters.AddWithValue("@Avalbillity", TxtAvailability.Text)

                conn.Open()
                cmd.ExecuteNonQuery()
                MessageBox.Show("Instructor updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LoadInstructors()
            End Using
        Else
            MessageBox.Show("Please select an instructor to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub
End Class

Public Class StudentManagementForm
    Private Sub BtnBackToDashboard_Click(sender As Object, e As EventArgs) Handles BtnBackToDashboard.Click
        Me.Close() ' Closes the current form and returns to the dashboard
    End Sub
End Class