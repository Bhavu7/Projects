' Certificate Management Form (CertificateManagementForm.vb)
Imports System.Data.SqlClient

Public Class CertificateManagementForm
    Private connectionString As String = "Server=YOUR_SERVER_NAME;Database=DanceAcademyDB;Integrated Security=True;"

    Private Sub CertificateManagementForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadCertificates()
    End Sub

    Private Sub LoadCertificates()
        Using conn As New SqlConnection(connectionString)
            Dim query As String = "SELECT * FROM Certificate"
            Dim adapter As New SqlDataAdapter(query, conn)
            Dim table As New DataTable()

            adapter.Fill(table)
            DataGridViewCertificates.DataSource = table
        End Using
    End Sub

    Private Sub BtnAddCertificate_Click(sender As Object, e As EventArgs) Handles BtnAddCertificate.Click
        Using conn As New SqlConnection(connectionString)
            Dim query As String = "INSERT INTO Certificate (Stdfname, Stdlname, Dtype, Duration) VALUES (@Stdfname, @Stdlname, @Dtype, @Duration)"
            Dim cmd As New SqlCommand(query, conn)

            cmd.Parameters.AddWithValue("@Stdfname", TxtFirstName.Text)
            cmd.Parameters.AddWithValue("@Stdlname", TxtLastName.Text)
            cmd.Parameters.AddWithValue("@Dtype", TxtDanceType.Text)
            cmd.Parameters.AddWithValue("@Duration", TxtDuration.Text)

            conn.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Certificate added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LoadCertificates()
        End Using
    End Sub

    Private Sub BtnDeleteCertificate_Click(sender As Object, e As EventArgs) Handles BtnDeleteCertificate.Click
        If DataGridViewCertificates.SelectedRows.Count > 0 Then
            Dim certID As Integer = Convert.ToInt32(DataGridViewCertificates.SelectedRows(0).Cells("CertificateID").Value)

            Using conn As New SqlConnection(connectionString)
                Dim query As String = "DELETE FROM Certificate WHERE CertificateID = @CertificateID"
                Dim cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@CertificateID", certID)

                conn.Open()
                cmd.ExecuteNonQuery()
                MessageBox.Show("Certificate deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LoadCertificates()
            End Using
        Else
            MessageBox.Show("Please select a certificate to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub BtnUpdateCertificate_Click(sender As Object, e As EventArgs) Handles BtnUpdateCertificate.Click
        If DataGridViewCertificates.SelectedRows.Count > 0 Then
            Dim certID As Integer = Convert.ToInt32(DataGridViewCertificates.SelectedRows(0).Cells("CertificateID").Value)

            Using conn As New SqlConnection(connectionString)
                Dim query As String = "UPDATE Certificate SET Stdfname = @Stdfname, Stdlname = @Stdlname, Dtype = @Dtype, Duration = @Duration WHERE CertificateID = @CertificateID"
                Dim cmd As New SqlCommand(query, conn)

                cmd.Parameters.AddWithValue("@CertificateID", certID)
                cmd.Parameters.AddWithValue("@Stdfname", TxtFirstName.Text)
                cmd.Parameters.AddWithValue("@Stdlname", TxtLastName.Text)
                cmd.Parameters.AddWithValue("@Dtype", TxtDanceType.Text)
                cmd.Parameters.AddWithValue("@Duration", TxtDuration.Text)

                conn.Open()
                cmd.ExecuteNonQuery()
                MessageBox.Show("Certificate updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LoadCertificates()
            End Using
        Else
            MessageBox.Show("Please select a certificate to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub
End Class

Public Class StudentManagementForm
    Private Sub BtnBackToDashboard_Click(sender As Object, e As EventArgs) Handles BtnBackToDashboard.Click
        Me.Close() ' Closes the current form and returns to the dashboard
    End Sub
End Class