' Batch Management Form (BatchManagementForm.vb)
Imports System.Data.SqlClient

Public Class BatchManagementForm
    Private connectionString As String = "Server=YOUR_SERVER_NAME;Database=DanceAcademyDB;Integrated Security=True;"

    Private Sub BatchManagementForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadBatches()
    End Sub

    Private Sub LoadBatches()
        Using conn As New SqlConnection(connectionString)
            Dim query As String = "SELECT * FROM Batchsch"
            Dim adapter As New SqlDataAdapter(query, conn)
            Dim table As New DataTable()

            adapter.Fill(table)
            DataGridViewBatches.DataSource = table
        End Using
    End Sub

    Private Sub BtnAddBatch_Click(sender As Object, e As EventArgs) Handles BtnAddBatch.Click
        Using conn As New SqlConnection(connectionString)
            Dim query As String = "INSERT INTO Batchsch (Batch_id, Dtype, Ins_id, Sdate, Edate, Time, Fees) VALUES (@Batch_id, @Dtype, @Ins_id, @Sdate, @Edate, @Time, @Fees)"
            Dim cmd As New SqlCommand(query, conn)

            cmd.Parameters.AddWithValue("@Batch_id", TxtBatchID.Text)
            cmd.Parameters.AddWithValue("@Dtype", TxtDanceType.Text)
            cmd.Parameters.AddWithValue("@Ins_id", TxtInstructorID.Text)
            cmd.Parameters.AddWithValue("@Sdate", DtpStartDate.Value)
            cmd.Parameters.AddWithValue("@Edate", DtpEndDate.Value)
            cmd.Parameters.AddWithValue("@Time", TxtTime.Text)
            cmd.Parameters.AddWithValue("@Fees", TxtFees.Text)

            conn.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Batch added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LoadBatches()
        End Using
    End Sub

    Private Sub BtnDeleteBatch_Click(sender As Object, e As EventArgs) Handles BtnDeleteBatch.Click
        If DataGridViewBatches.SelectedRows.Count > 0 Then
            Dim batchID As String = DataGridViewBatches.SelectedRows(0).Cells("Batch_id").Value.ToString()

            Using conn As New SqlConnection(connectionString)
                Dim query As String = "DELETE FROM Batchsch WHERE Batch_id = @Batch_id"
                Dim cmd As New SqlCommand(query, conn)

                cmd.Parameters.AddWithValue("@Batch_id", batchID)

                conn.Open()
                cmd.ExecuteNonQuery()
                MessageBox.Show("Batch deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LoadBatches()
            End Using
        Else
            MessageBox.Show("Please select a batch to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub BtnUpdateBatch_Click(sender As Object, e As EventArgs) Handles BtnUpdateBatch.Click
        If DataGridViewBatches.SelectedRows.Count > 0 Then
            Dim batchID As String = DataGridViewBatches.SelectedRows(0).Cells("Batch_id").Value.ToString()

            Using conn As New SqlConnection(connectionString)
                Dim query As String = "UPDATE Batchsch SET Dtype = @Dtype, Ins_id = @Ins_id, Sdate = @Sdate, Edate = @Edate, Time = @Time, Fees = @Fees WHERE Batch_id = @Batch_id"
                Dim cmd As New SqlCommand(query, conn)

                cmd.Parameters.AddWithValue("@Batch_id", batchID)
                cmd.Parameters.AddWithValue("@Dtype", TxtDanceType.Text)
                cmd.Parameters.AddWithValue("@Ins_id", TxtInstructorID.Text)
                cmd.Parameters.AddWithValue("@Sdate", DtpStartDate.Value)
                cmd.Parameters.AddWithValue("@Edate", DtpEndDate.Value)
                cmd.Parameters.AddWithValue("@Time", TxtTime.Text)
                cmd.Parameters.AddWithValue("@Fees", TxtFees.Text)

                conn.Open()
                cmd.ExecuteNonQuery()
                MessageBox.Show("Batch updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LoadBatches()
            End Using
        Else
            MessageBox.Show("Please select a batch to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub
End Class

Public Class StudentManagementForm
    Private Sub BtnBackToDashboard_Click(sender As Object, e As EventArgs) Handles BtnBackToDashboard.Click
        Me.Close() ' Closes the current form and returns to the dashboard
    End Sub
End Class
















' with template 


Imports System.Data.SqlClient
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports System.IO

Public Class CertificateManagementForm
    Private connectionString As String = "Server=YOUR_SERVER_NAME;Database=DanceAcademyDB;Integrated Security=True;"

    ' Download Certificate with Template
    Private Sub BtnDownloadCertificate_Click(sender As Object, e As EventArgs) Handles BtnDownloadCertificate.Click
        If DataGridViewCertificates.SelectedRows.Count > 0 Then
            Dim certID As Integer = Convert.ToInt32(DataGridViewCertificates.SelectedRows(0).Cells("CertificateID").Value)

            Using conn As New SqlConnection(connectionString)
                Dim query As String = "SELECT * FROM Certificate WHERE CertificateID = @CertificateID"
                Dim cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@CertificateID", certID)

                conn.Open()
                Dim reader As SqlDataReader = cmd.ExecuteReader()

                If reader.Read() Then
                    Dim firstName As String = reader("Stdfname").ToString()
                    Dim lastName As String = reader("Stdlname").ToString()
                    Dim danceType As String = reader("Dtype").ToString()
                    Dim duration As String = reader("Duration").ToString()

                    ' Certificate Details
                    Dim fullName As String = $"{firstName} {lastName}"
                    Dim filePath As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), $"Certificate_{certID}.pdf")

                    ' Create PDF
                    Dim document As New Document(PageSize.A4)
                    PdfWriter.GetInstance(document, New FileStream(filePath, FileMode.Create))

                    document.Open()

                    ' Add Template Image
                    Dim templatePath As String = "CertificateTemplate.png" ' Path to your template image
                    Dim templateImage As iTextSharp.text.Image = iTextSharp.text.Image.GetInstance(templatePath)
                    templateImage.SetAbsolutePosition(0, 0) ' Adjust position as needed
                    templateImage.ScaleToFit(PageSize.A4.Width, PageSize.A4.Height) ' Fit to A4 size
                    document.Add(templateImage)

                    ' Overlay Text
                    Dim font As New Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, BaseColor.BLACK)

                    ' Add Name
                    Dim cb As PdfContentByte = PdfWriter.GetInstance(document, New FileStream(filePath, FileMode.Create)).DirectContent
                    ColumnText.ShowTextAligned(cb, Element.ALIGN_CENTER, New Phrase(fullName, font), 300, 500, 0) ' Adjust X, Y positions as needed

                    ' Add Dance Type
                    ColumnText.ShowTextAligned(cb, Element.ALIGN_CENTER, New Phrase(danceType, font), 300, 450, 0)

                    ' Add Duration
                    ColumnText.ShowTextAligned(cb, Element.ALIGN_CENTER, New Phrase($"Duration: {duration}", font), 300, 400, 0)

                    document.Close()

                    MessageBox.Show($"Certificate downloaded successfully at {filePath}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End Using
        Else
            MessageBox.Show("Please select a certificate to download.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub
End Class
