﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CertificateManagementForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BtnBackToDashboard = New System.Windows.Forms.Button()
        Me.BtnDeleteCertificate = New System.Windows.Forms.Button()
        Me.BtnUpdateCertificate = New System.Windows.Forms.Button()
        Me.BtnAddCertificate = New System.Windows.Forms.Button()
        Me.TxtDanceType = New System.Windows.Forms.TextBox()
        Me.TxtLastName = New System.Windows.Forms.TextBox()
        Me.TxtFirstName = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridViewCertificates = New System.Windows.Forms.DataGridView()
        Me.StudID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StudFname = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StudLname = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.email = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Address = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gender = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.age = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DanceType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtDuration = New System.Windows.Forms.TextBox()
        CType(Me.DataGridViewCertificates, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BtnBackToDashboard
        '
        Me.BtnBackToDashboard.Location = New System.Drawing.Point(716, 334)
        Me.BtnBackToDashboard.Name = "BtnBackToDashboard"
        Me.BtnBackToDashboard.Size = New System.Drawing.Size(205, 33)
        Me.BtnBackToDashboard.TabIndex = 47
        Me.BtnBackToDashboard.Text = "Back"
        Me.BtnBackToDashboard.UseVisualStyleBackColor = True
        '
        'BtnDeleteCertificate
        '
        Me.BtnDeleteCertificate.Location = New System.Drawing.Point(716, 268)
        Me.BtnDeleteCertificate.Name = "BtnDeleteCertificate"
        Me.BtnDeleteCertificate.Size = New System.Drawing.Size(205, 33)
        Me.BtnDeleteCertificate.TabIndex = 45
        Me.BtnDeleteCertificate.Text = "DELETE CERTIFICATE"
        Me.BtnDeleteCertificate.UseVisualStyleBackColor = True
        '
        'BtnUpdateCertificate
        '
        Me.BtnUpdateCertificate.Location = New System.Drawing.Point(716, 199)
        Me.BtnUpdateCertificate.Name = "BtnUpdateCertificate"
        Me.BtnUpdateCertificate.Size = New System.Drawing.Size(205, 33)
        Me.BtnUpdateCertificate.TabIndex = 44
        Me.BtnUpdateCertificate.Text = "UPDATE CERTIFICATE"
        Me.BtnUpdateCertificate.UseVisualStyleBackColor = True
        '
        'BtnAddCertificate
        '
        Me.BtnAddCertificate.Location = New System.Drawing.Point(716, 125)
        Me.BtnAddCertificate.Name = "BtnAddCertificate"
        Me.BtnAddCertificate.Size = New System.Drawing.Size(205, 33)
        Me.BtnAddCertificate.TabIndex = 43
        Me.BtnAddCertificate.Text = "ADD CERTIFICATE"
        Me.BtnAddCertificate.UseVisualStyleBackColor = True
        '
        'TxtDanceType
        '
        Me.TxtDanceType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtDanceType.Location = New System.Drawing.Point(284, 233)
        Me.TxtDanceType.Name = "TxtDanceType"
        Me.TxtDanceType.Size = New System.Drawing.Size(100, 22)
        Me.TxtDanceType.TabIndex = 42
        '
        'TxtLastName
        '
        Me.TxtLastName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtLastName.Location = New System.Drawing.Point(284, 197)
        Me.TxtLastName.Name = "TxtLastName"
        Me.TxtLastName.Size = New System.Drawing.Size(100, 22)
        Me.TxtLastName.TabIndex = 36
        '
        'TxtFirstName
        '
        Me.TxtFirstName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtFirstName.Location = New System.Drawing.Point(284, 163)
        Me.TxtFirstName.Name = "TxtFirstName"
        Me.TxtFirstName.Size = New System.Drawing.Size(100, 22)
        Me.TxtFirstName.TabIndex = 35
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(163, 233)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(97, 17)
        Me.Label10.TabIndex = 33
        Me.Label10.Text = "Dance Type : "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(172, 199)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 17)
        Me.Label4.TabIndex = 27
        Me.Label4.Text = "Last Name : "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(172, 165)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 17)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "First Name : "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(375, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(324, 31)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "Certificate Management"
        '
        'DataGridViewCertificates
        '
        Me.DataGridViewCertificates.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewCertificates.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.StudID, Me.StudFname, Me.StudLname, Me.Cno, Me.email, Me.Address, Me.gender, Me.age, Me.DanceType})
        Me.DataGridViewCertificates.Location = New System.Drawing.Point(71, 523)
        Me.DataGridViewCertificates.Name = "DataGridViewCertificates"
        Me.DataGridViewCertificates.RowTemplate.Height = 24
        Me.DataGridViewCertificates.Size = New System.Drawing.Size(945, 67)
        Me.DataGridViewCertificates.TabIndex = 48
        '
        'StudID
        '
        Me.StudID.HeaderText = "Student ID"
        Me.StudID.Name = "StudID"
        '
        'StudFname
        '
        Me.StudFname.HeaderText = "First Name"
        Me.StudFname.Name = "StudFname"
        '
        'StudLname
        '
        Me.StudLname.HeaderText = "Last Name"
        Me.StudLname.Name = "StudLname"
        '
        'Cno
        '
        Me.Cno.HeaderText = "Contact No"
        Me.Cno.Name = "Cno"
        '
        'email
        '
        Me.email.HeaderText = "E-mail"
        Me.email.Name = "email"
        '
        'Address
        '
        Me.Address.HeaderText = "Address"
        Me.Address.Name = "Address"
        '
        'gender
        '
        Me.gender.HeaderText = "Gender"
        Me.gender.Name = "gender"
        '
        'age
        '
        Me.age.HeaderText = "Age"
        Me.age.Name = "age"
        '
        'DanceType
        '
        Me.DanceType.HeaderText = "Dance Type"
        Me.DanceType.Name = "DanceType"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(186, 268)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 17)
        Me.Label2.TabIndex = 49
        Me.Label2.Text = "Duration : "
        '
        'TxtDuration
        '
        Me.TxtDuration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtDuration.Location = New System.Drawing.Point(284, 268)
        Me.TxtDuration.Name = "TxtDuration"
        Me.TxtDuration.Size = New System.Drawing.Size(100, 22)
        Me.TxtDuration.TabIndex = 50
        '
        'CertificateManagementForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1092, 731)
        Me.Controls.Add(Me.TxtDuration)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.DataGridViewCertificates)
        Me.Controls.Add(Me.BtnBackToDashboard)
        Me.Controls.Add(Me.BtnDeleteCertificate)
        Me.Controls.Add(Me.BtnUpdateCertificate)
        Me.Controls.Add(Me.BtnAddCertificate)
        Me.Controls.Add(Me.TxtDanceType)
        Me.Controls.Add(Me.TxtLastName)
        Me.Controls.Add(Me.TxtFirstName)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Name = "CertificateManagementForm"
        Me.Text = "CertificateManagementForm"
        CType(Me.DataGridViewCertificates, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BtnBackToDashboard As System.Windows.Forms.Button
    Friend WithEvents BtnDeleteCertificate As System.Windows.Forms.Button
    Friend WithEvents BtnUpdateCertificate As System.Windows.Forms.Button
    Friend WithEvents BtnAddCertificate As System.Windows.Forms.Button
    Friend WithEvents TxtDanceType As System.Windows.Forms.TextBox
    Friend WithEvents TxtLastName As System.Windows.Forms.TextBox
    Friend WithEvents TxtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DataGridViewCertificates As System.Windows.Forms.DataGridView
    Friend WithEvents StudID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StudFname As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StudLname As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cno As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents email As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Address As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents gender As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents age As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DanceType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TxtDuration As System.Windows.Forms.TextBox
End Class
