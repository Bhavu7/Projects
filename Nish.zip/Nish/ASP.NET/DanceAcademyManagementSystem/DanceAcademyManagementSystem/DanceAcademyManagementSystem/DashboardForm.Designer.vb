﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DashboardForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BtnManageStudents = New System.Windows.Forms.Button()
        Me.BtnManageInstructors = New System.Windows.Forms.Button()
        Me.BtnManageBatches = New System.Windows.Forms.Button()
        Me.BtnAssignBatch = New System.Windows.Forms.Button()
        Me.BtnCertificates = New System.Windows.Forms.Button()
        Me.BtnLogout = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'BtnManageStudents
        '
        Me.BtnManageStudents.Location = New System.Drawing.Point(187, 104)
        Me.BtnManageStudents.Name = "BtnManageStudents"
        Me.BtnManageStudents.Size = New System.Drawing.Size(150, 34)
        Me.BtnManageStudents.TabIndex = 0
        Me.BtnManageStudents.Text = "Manage Students"
        Me.BtnManageStudents.UseVisualStyleBackColor = True
        '
        'BtnManageInstructors
        '
        Me.BtnManageInstructors.Location = New System.Drawing.Point(187, 196)
        Me.BtnManageInstructors.Name = "BtnManageInstructors"
        Me.BtnManageInstructors.Size = New System.Drawing.Size(150, 34)
        Me.BtnManageInstructors.TabIndex = 1
        Me.BtnManageInstructors.Text = "Manage Instructors"
        Me.BtnManageInstructors.UseVisualStyleBackColor = True
        '
        'BtnManageBatches
        '
        Me.BtnManageBatches.Location = New System.Drawing.Point(474, 104)
        Me.BtnManageBatches.Name = "BtnManageBatches"
        Me.BtnManageBatches.Size = New System.Drawing.Size(150, 34)
        Me.BtnManageBatches.TabIndex = 2
        Me.BtnManageBatches.Text = "Manage Batches"
        Me.BtnManageBatches.UseVisualStyleBackColor = True
        '
        'BtnAssignBatch
        '
        Me.BtnAssignBatch.Location = New System.Drawing.Point(474, 196)
        Me.BtnAssignBatch.Name = "BtnAssignBatch"
        Me.BtnAssignBatch.Size = New System.Drawing.Size(150, 34)
        Me.BtnAssignBatch.TabIndex = 3
        Me.BtnAssignBatch.Text = "Assign Batch"
        Me.BtnAssignBatch.UseVisualStyleBackColor = True
        '
        'BtnCertificates
        '
        Me.BtnCertificates.Location = New System.Drawing.Point(768, 104)
        Me.BtnCertificates.Name = "BtnCertificates"
        Me.BtnCertificates.Size = New System.Drawing.Size(150, 34)
        Me.BtnCertificates.TabIndex = 4
        Me.BtnCertificates.Text = "Manage Certificates"
        Me.BtnCertificates.UseVisualStyleBackColor = True
        '
        'BtnLogout
        '
        Me.BtnLogout.Location = New System.Drawing.Point(768, 196)
        Me.BtnLogout.Name = "BtnLogout"
        Me.BtnLogout.Size = New System.Drawing.Size(150, 34)
        Me.BtnLogout.TabIndex = 5
        Me.BtnLogout.Text = "Log Out"
        Me.BtnLogout.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(437, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(230, 31)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Admin Dashboard"
        '
        'DashboardForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1099, 427)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BtnLogout)
        Me.Controls.Add(Me.BtnCertificates)
        Me.Controls.Add(Me.BtnAssignBatch)
        Me.Controls.Add(Me.BtnManageBatches)
        Me.Controls.Add(Me.BtnManageInstructors)
        Me.Controls.Add(Me.BtnManageStudents)
        Me.Name = "DashboardForm"
        Me.Text = "DashboardForm"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BtnManageStudents As System.Windows.Forms.Button
    Friend WithEvents BtnManageInstructors As System.Windows.Forms.Button
    Friend WithEvents BtnManageBatches As System.Windows.Forms.Button
    Friend WithEvents BtnAssignBatch As System.Windows.Forms.Button
    Friend WithEvents BtnCertificates As System.Windows.Forms.Button
    Friend WithEvents BtnLogout As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
