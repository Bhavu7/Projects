﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StudentManagementForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TxtStudentID = New System.Windows.Forms.TextBox()
        Me.TxtFirstName = New System.Windows.Forms.TextBox()
        Me.TxtLastName = New System.Windows.Forms.TextBox()
        Me.TxtContact = New System.Windows.Forms.TextBox()
        Me.TxtEmail = New System.Windows.Forms.TextBox()
        Me.TxtAddress = New System.Windows.Forms.TextBox()
        Me.CmbGender = New System.Windows.Forms.ComboBox()
        Me.TxtAge = New System.Windows.Forms.TextBox()
        Me.TxtDanceType = New System.Windows.Forms.TextBox()
        Me.BtnAddStudent = New System.Windows.Forms.Button()
        Me.BtnUpdateStudent = New System.Windows.Forms.Button()
        Me.BtnDeleteStudent = New System.Windows.Forms.Button()
        Me.BtnBackToDashboard = New System.Windows.Forms.Button()
        Me.DataGridViewStudents = New System.Windows.Forms.DataGridView()
        Me.StudID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StudFname = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StudLname = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.email = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Address = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gender = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.age = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DanceType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridViewStudents, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(398, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(290, 31)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Student Management"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(195, 128)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(86, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Student ID : "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(195, 161)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "First Name : "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(195, 195)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Last Name : "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(195, 231)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(90, 17)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Contact No : "
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(195, 266)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 17)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "E-mail : "
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(195, 297)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(72, 17)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Address : "
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(195, 330)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(68, 17)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Gender : "
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(195, 364)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(45, 17)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Age : "
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(195, 398)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(97, 17)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Dance Type : "
        '
        'TxtStudentID
        '
        Me.TxtStudentID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtStudentID.Location = New System.Drawing.Point(307, 128)
        Me.TxtStudentID.Name = "TxtStudentID"
        Me.TxtStudentID.Size = New System.Drawing.Size(100, 22)
        Me.TxtStudentID.TabIndex = 10
        '
        'TxtFirstName
        '
        Me.TxtFirstName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtFirstName.Location = New System.Drawing.Point(307, 159)
        Me.TxtFirstName.Name = "TxtFirstName"
        Me.TxtFirstName.Size = New System.Drawing.Size(100, 22)
        Me.TxtFirstName.TabIndex = 11
        '
        'TxtLastName
        '
        Me.TxtLastName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtLastName.Location = New System.Drawing.Point(307, 193)
        Me.TxtLastName.Name = "TxtLastName"
        Me.TxtLastName.Size = New System.Drawing.Size(100, 22)
        Me.TxtLastName.TabIndex = 12
        '
        'TxtContact
        '
        Me.TxtContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtContact.Location = New System.Drawing.Point(307, 229)
        Me.TxtContact.Name = "TxtContact"
        Me.TxtContact.Size = New System.Drawing.Size(100, 22)
        Me.TxtContact.TabIndex = 13
        '
        'TxtEmail
        '
        Me.TxtEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtEmail.Location = New System.Drawing.Point(307, 264)
        Me.TxtEmail.Name = "TxtEmail"
        Me.TxtEmail.Size = New System.Drawing.Size(100, 22)
        Me.TxtEmail.TabIndex = 14
        '
        'TxtAddress
        '
        Me.TxtAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtAddress.Location = New System.Drawing.Point(307, 295)
        Me.TxtAddress.Name = "TxtAddress"
        Me.TxtAddress.Size = New System.Drawing.Size(100, 22)
        Me.TxtAddress.TabIndex = 15
        '
        'CmbGender
        '
        Me.CmbGender.FormattingEnabled = True
        Me.CmbGender.Items.AddRange(New Object() {"Male", "Female"})
        Me.CmbGender.Location = New System.Drawing.Point(307, 327)
        Me.CmbGender.Name = "CmbGender"
        Me.CmbGender.Size = New System.Drawing.Size(121, 24)
        Me.CmbGender.TabIndex = 16
        '
        'TxtAge
        '
        Me.TxtAge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtAge.Location = New System.Drawing.Point(307, 362)
        Me.TxtAge.Name = "TxtAge"
        Me.TxtAge.Size = New System.Drawing.Size(100, 22)
        Me.TxtAge.TabIndex = 17
        '
        'TxtDanceType
        '
        Me.TxtDanceType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtDanceType.Location = New System.Drawing.Point(307, 396)
        Me.TxtDanceType.Name = "TxtDanceType"
        Me.TxtDanceType.Size = New System.Drawing.Size(100, 22)
        Me.TxtDanceType.TabIndex = 18
        '
        'BtnAddStudent
        '
        Me.BtnAddStudent.Location = New System.Drawing.Point(739, 121)
        Me.BtnAddStudent.Name = "BtnAddStudent"
        Me.BtnAddStudent.Size = New System.Drawing.Size(205, 33)
        Me.BtnAddStudent.TabIndex = 19
        Me.BtnAddStudent.Text = "ADD STUDENT"
        Me.BtnAddStudent.UseVisualStyleBackColor = True
        '
        'BtnUpdateStudent
        '
        Me.BtnUpdateStudent.Location = New System.Drawing.Point(739, 215)
        Me.BtnUpdateStudent.Name = "BtnUpdateStudent"
        Me.BtnUpdateStudent.Size = New System.Drawing.Size(205, 33)
        Me.BtnUpdateStudent.TabIndex = 20
        Me.BtnUpdateStudent.Text = "UPDATE STUDENT"
        Me.BtnUpdateStudent.UseVisualStyleBackColor = True
        '
        'BtnDeleteStudent
        '
        Me.BtnDeleteStudent.Location = New System.Drawing.Point(739, 297)
        Me.BtnDeleteStudent.Name = "BtnDeleteStudent"
        Me.BtnDeleteStudent.Size = New System.Drawing.Size(205, 33)
        Me.BtnDeleteStudent.TabIndex = 21
        Me.BtnDeleteStudent.Text = "DELETE STUDENT"
        Me.BtnDeleteStudent.UseVisualStyleBackColor = True
        '
        'BtnBackToDashboard
        '
        Me.BtnBackToDashboard.Location = New System.Drawing.Point(739, 385)
        Me.BtnBackToDashboard.Name = "BtnBackToDashboard"
        Me.BtnBackToDashboard.Size = New System.Drawing.Size(205, 33)
        Me.BtnBackToDashboard.TabIndex = 23
        Me.BtnBackToDashboard.Text = "Back"
        Me.BtnBackToDashboard.UseVisualStyleBackColor = True
        '
        'DataGridViewStudents
        '
        Me.DataGridViewStudents.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewStudents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewStudents.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.StudID, Me.StudFname, Me.StudLname, Me.Cno, Me.email, Me.Address, Me.gender, Me.age, Me.DanceType})
        Me.DataGridViewStudents.Location = New System.Drawing.Point(53, 500)
        Me.DataGridViewStudents.Name = "DataGridViewStudents"
        Me.DataGridViewStudents.RowTemplate.Height = 24
        Me.DataGridViewStudents.Size = New System.Drawing.Size(945, 316)
        Me.DataGridViewStudents.TabIndex = 24
        '
        'StudID
        '
        Me.StudID.HeaderText = "Student ID"
        Me.StudID.Name = "StudID"
        '
        'StudFname
        '
        Me.StudFname.HeaderText = "First Name"
        Me.StudFname.Name = "StudFname"
        '
        'StudLname
        '
        Me.StudLname.HeaderText = "Last Name"
        Me.StudLname.Name = "StudLname"
        '
        'Cno
        '
        Me.Cno.HeaderText = "Contact No"
        Me.Cno.Name = "Cno"
        '
        'email
        '
        Me.email.HeaderText = "E-mail"
        Me.email.Name = "email"
        '
        'Address
        '
        Me.Address.HeaderText = "Address"
        Me.Address.Name = "Address"
        '
        'gender
        '
        Me.gender.HeaderText = "Gender"
        Me.gender.Name = "gender"
        '
        'age
        '
        Me.age.HeaderText = "Age"
        Me.age.Name = "age"
        '
        'DanceType
        '
        Me.DanceType.HeaderText = "Dance Type"
        Me.DanceType.Name = "DanceType"
        '
        'StudentManagementForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1094, 1040)
        Me.Controls.Add(Me.DataGridViewStudents)
        Me.Controls.Add(Me.BtnBackToDashboard)
        Me.Controls.Add(Me.BtnDeleteStudent)
        Me.Controls.Add(Me.BtnUpdateStudent)
        Me.Controls.Add(Me.BtnAddStudent)
        Me.Controls.Add(Me.TxtDanceType)
        Me.Controls.Add(Me.TxtAge)
        Me.Controls.Add(Me.CmbGender)
        Me.Controls.Add(Me.TxtAddress)
        Me.Controls.Add(Me.TxtEmail)
        Me.Controls.Add(Me.TxtContact)
        Me.Controls.Add(Me.TxtLastName)
        Me.Controls.Add(Me.TxtFirstName)
        Me.Controls.Add(Me.TxtStudentID)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "StudentManagementForm"
        Me.Text = "StudentManagementForm"
        CType(Me.DataGridViewStudents, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TxtStudentID As System.Windows.Forms.TextBox
    Friend WithEvents TxtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents TxtLastName As System.Windows.Forms.TextBox
    Friend WithEvents TxtContact As System.Windows.Forms.TextBox
    Friend WithEvents TxtEmail As System.Windows.Forms.TextBox
    Friend WithEvents TxtAddress As System.Windows.Forms.TextBox
    Friend WithEvents CmbGender As System.Windows.Forms.ComboBox
    Friend WithEvents TxtAge As System.Windows.Forms.TextBox
    Friend WithEvents TxtDanceType As System.Windows.Forms.TextBox
    Friend WithEvents BtnAddStudent As System.Windows.Forms.Button
    Friend WithEvents BtnUpdateStudent As System.Windows.Forms.Button
    Friend WithEvents BtnDeleteStudent As System.Windows.Forms.Button
    Friend WithEvents BtnBackToDashboard As System.Windows.Forms.Button
    Friend WithEvents DataGridViewStudents As System.Windows.Forms.DataGridView
    Friend WithEvents StudID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StudFname As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StudLname As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cno As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents email As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Address As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents gender As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents age As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DanceType As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
