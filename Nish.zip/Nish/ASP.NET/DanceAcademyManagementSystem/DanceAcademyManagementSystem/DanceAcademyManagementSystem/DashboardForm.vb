﻿' Updated Dashboard Form (DashboardForm.vb)
Public Class DashboardForm
    Private Sub BtnManageStudents_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnManageStudents.Click
        Dim studentForm As New StudentManagementForm()
        studentForm.ShowDialog()
    End Sub

    Private Sub BtnManageInstructors_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnManageInstructors.Click
        Dim instructorForm As New InstructorManagementForm()
        instructorForm.ShowDialog()
    End Sub

    Private Sub BtnManageBatches_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnManageBatches.Click
        Dim batchForm As New BatchManagementForm()
        batchForm.ShowDialog()
    End Sub

    Private Sub BtnAssignBatch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnAssignBatch.Click
        Dim assignBatchForm As New AssignBatchForm()
        assignBatchForm.ShowDialog()
    End Sub

    Private Sub BtnCertificates_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnCertificates.Click
        Dim certificateForm As New CertificateManagementForm()
        certificateForm.ShowDialog()
    End Sub

    Private Sub BtnLogout_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnLogout.Click
        Me.Close()
        Dim loginForm As New LoginForm()
        loginForm.Show()
    End Sub
End Class