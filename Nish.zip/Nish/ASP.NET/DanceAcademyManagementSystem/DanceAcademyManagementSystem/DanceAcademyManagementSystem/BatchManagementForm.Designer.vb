﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BatchManagementForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TxtBatchID = New System.Windows.Forms.TextBox()
        Me.TxtInstructorID = New System.Windows.Forms.TextBox()
        Me.DtpStartDate = New System.Windows.Forms.DateTimePicker()
        Me.DtpEndDate = New System.Windows.Forms.DateTimePicker()
        Me.TxtTime = New System.Windows.Forms.TextBox()
        Me.TxtDanceType = New System.Windows.Forms.TextBox()
        Me.TxtFees = New System.Windows.Forms.TextBox()
        Me.BtnBackToDashboard = New System.Windows.Forms.Button()
        Me.BtnDeleteBatch = New System.Windows.Forms.Button()
        Me.BtnUpdateBatch = New System.Windows.Forms.Button()
        Me.BtnAddBatch = New System.Windows.Forms.Button()
        Me.DataGridViewBatches = New System.Windows.Forms.DataGridView()
        Me.BatchID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.InstructorID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DanceType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StartDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EndDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Time = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Fees = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        CType(Me.DataGridViewBatches, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TxtBatchID
        '
        Me.TxtBatchID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtBatchID.Location = New System.Drawing.Point(302, 97)
        Me.TxtBatchID.Name = "TxtBatchID"
        Me.TxtBatchID.Size = New System.Drawing.Size(100, 22)
        Me.TxtBatchID.TabIndex = 0
        '
        'TxtInstructorID
        '
        Me.TxtInstructorID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtInstructorID.Location = New System.Drawing.Point(302, 143)
        Me.TxtInstructorID.Name = "TxtInstructorID"
        Me.TxtInstructorID.Size = New System.Drawing.Size(100, 22)
        Me.TxtInstructorID.TabIndex = 1
        '
        'DtpStartDate
        '
        Me.DtpStartDate.Location = New System.Drawing.Point(302, 232)
        Me.DtpStartDate.Name = "DtpStartDate"
        Me.DtpStartDate.Size = New System.Drawing.Size(200, 22)
        Me.DtpStartDate.TabIndex = 2
        '
        'DtpEndDate
        '
        Me.DtpEndDate.Location = New System.Drawing.Point(302, 274)
        Me.DtpEndDate.Name = "DtpEndDate"
        Me.DtpEndDate.Size = New System.Drawing.Size(200, 22)
        Me.DtpEndDate.TabIndex = 3
        '
        'TxtTime
        '
        Me.TxtTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtTime.Location = New System.Drawing.Point(302, 318)
        Me.TxtTime.Name = "TxtTime"
        Me.TxtTime.Size = New System.Drawing.Size(100, 22)
        Me.TxtTime.TabIndex = 18
        '
        'TxtDanceType
        '
        Me.TxtDanceType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtDanceType.Location = New System.Drawing.Point(302, 184)
        Me.TxtDanceType.Name = "TxtDanceType"
        Me.TxtDanceType.Size = New System.Drawing.Size(100, 22)
        Me.TxtDanceType.TabIndex = 19
        '
        'TxtFees
        '
        Me.TxtFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtFees.Location = New System.Drawing.Point(302, 350)
        Me.TxtFees.Name = "TxtFees"
        Me.TxtFees.Size = New System.Drawing.Size(100, 22)
        Me.TxtFees.TabIndex = 20
        '
        'BtnBackToDashboard
        '
        Me.BtnBackToDashboard.Location = New System.Drawing.Point(746, 352)
        Me.BtnBackToDashboard.Name = "BtnBackToDashboard"
        Me.BtnBackToDashboard.Size = New System.Drawing.Size(205, 33)
        Me.BtnBackToDashboard.TabIndex = 27
        Me.BtnBackToDashboard.Text = "Back"
        Me.BtnBackToDashboard.UseVisualStyleBackColor = True
        '
        'BtnDeleteBatch
        '
        Me.BtnDeleteBatch.Location = New System.Drawing.Point(746, 264)
        Me.BtnDeleteBatch.Name = "BtnDeleteBatch"
        Me.BtnDeleteBatch.Size = New System.Drawing.Size(205, 33)
        Me.BtnDeleteBatch.TabIndex = 26
        Me.BtnDeleteBatch.Text = "DELETE BATCH"
        Me.BtnDeleteBatch.UseVisualStyleBackColor = True
        '
        'BtnUpdateBatch
        '
        Me.BtnUpdateBatch.Location = New System.Drawing.Point(746, 182)
        Me.BtnUpdateBatch.Name = "BtnUpdateBatch"
        Me.BtnUpdateBatch.Size = New System.Drawing.Size(205, 33)
        Me.BtnUpdateBatch.TabIndex = 25
        Me.BtnUpdateBatch.Text = "UPDATE BATCH"
        Me.BtnUpdateBatch.UseVisualStyleBackColor = True
        '
        'BtnAddBatch
        '
        Me.BtnAddBatch.Location = New System.Drawing.Point(746, 88)
        Me.BtnAddBatch.Name = "BtnAddBatch"
        Me.BtnAddBatch.Size = New System.Drawing.Size(205, 33)
        Me.BtnAddBatch.TabIndex = 24
        Me.BtnAddBatch.Text = "ADD BATCH"
        Me.BtnAddBatch.UseVisualStyleBackColor = True
        '
        'DataGridViewBatches
        '
        Me.DataGridViewBatches.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewBatches.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewBatches.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.BatchID, Me.InstructorID, Me.DanceType, Me.StartDate, Me.EndDate, Me.Time, Me.Fees})
        Me.DataGridViewBatches.Location = New System.Drawing.Point(208, 442)
        Me.DataGridViewBatches.Name = "DataGridViewBatches"
        Me.DataGridViewBatches.RowTemplate.Height = 24
        Me.DataGridViewBatches.Size = New System.Drawing.Size(743, 150)
        Me.DataGridViewBatches.TabIndex = 28
        '
        'BatchID
        '
        Me.BatchID.HeaderText = "Batch ID"
        Me.BatchID.Name = "BatchID"
        '
        'InstructorID
        '
        Me.InstructorID.HeaderText = "Instructor ID"
        Me.InstructorID.Name = "InstructorID"
        '
        'DanceType
        '
        Me.DanceType.HeaderText = "Dance Type"
        Me.DanceType.Name = "DanceType"
        '
        'StartDate
        '
        Me.StartDate.HeaderText = "Start Date"
        Me.StartDate.Name = "StartDate"
        '
        'EndDate
        '
        Me.EndDate.HeaderText = "End Date"
        Me.EndDate.Name = "EndDate"
        '
        'Time
        '
        Me.Time.HeaderText = "Time"
        Me.Time.Name = "Time"
        '
        'Fees
        '
        Me.Fees.HeaderText = "Fees"
        Me.Fees.Name = "Fees"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(205, 99)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 17)
        Me.Label1.TabIndex = 29
        Me.Label1.Text = "Batch ID : "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(205, 145)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 17)
        Me.Label2.TabIndex = 30
        Me.Label2.Text = "Instructor ID : "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(205, 186)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(97, 17)
        Me.Label3.TabIndex = 31
        Me.Label3.Text = "Dance Type : "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(205, 232)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 17)
        Me.Label4.TabIndex = 32
        Me.Label4.Text = "Start Date : "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(205, 272)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(79, 17)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "End Date : "
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(205, 318)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(51, 17)
        Me.Label6.TabIndex = 34
        Me.Label6.Text = "Time : "
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(205, 355)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(51, 17)
        Me.Label7.TabIndex = 35
        Me.Label7.Text = "Fees : "
        '
        'BatchManagementForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1118, 797)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DataGridViewBatches)
        Me.Controls.Add(Me.BtnBackToDashboard)
        Me.Controls.Add(Me.BtnDeleteBatch)
        Me.Controls.Add(Me.BtnUpdateBatch)
        Me.Controls.Add(Me.BtnAddBatch)
        Me.Controls.Add(Me.TxtFees)
        Me.Controls.Add(Me.TxtDanceType)
        Me.Controls.Add(Me.TxtTime)
        Me.Controls.Add(Me.DtpEndDate)
        Me.Controls.Add(Me.DtpStartDate)
        Me.Controls.Add(Me.TxtInstructorID)
        Me.Controls.Add(Me.TxtBatchID)
        Me.Name = "BatchManagementForm"
        Me.Text = "BatchManagementForm"
        CType(Me.DataGridViewBatches, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TxtBatchID As System.Windows.Forms.TextBox
    Friend WithEvents TxtInstructorID As System.Windows.Forms.TextBox
    Friend WithEvents DtpStartDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents DtpEndDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents TxtTime As System.Windows.Forms.TextBox
    Friend WithEvents TxtDanceType As System.Windows.Forms.TextBox
    Friend WithEvents TxtFees As System.Windows.Forms.TextBox
    Friend WithEvents BtnBackToDashboard As System.Windows.Forms.Button
    Friend WithEvents BtnDeleteBatch As System.Windows.Forms.Button
    Friend WithEvents BtnUpdateBatch As System.Windows.Forms.Button
    Friend WithEvents BtnAddBatch As System.Windows.Forms.Button
    Friend WithEvents DataGridViewBatches As System.Windows.Forms.DataGridView
    Friend WithEvents BatchID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents InstructorID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DanceType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StartDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EndDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Time As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Fees As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
End Class
