﻿' Batch Management Form (BatchManagementForm.vb)
Imports System.Data.SqlClient

Public Class BatchManagementForm
    Private connectionString As String = "Server=localhost\SQLEXPRESS;Database=DanceAcademyDB;Integrated Security=True;"

    Private Sub BatchManagementForm_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        LoadBatches()
    End Sub

    Private Sub LoadBatches()
        Using conn As New SqlConnection(connectionString)
            Dim query As String = "SELECT * FROM Batchsch"
            Dim adapter As New SqlDataAdapter(query, conn)
            Dim table As New DataTable()

            adapter.Fill(table)
            DataGridViewBatches.DataSource = table
        End Using
    End Sub

    Private Sub BtnAddBatch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnAddBatch.Click
        Using conn As New SqlConnection(connectionString)
            Dim query As String = "INSERT INTO Batchsch (Batch_id, Dtype, Ins_id, Sdate, Edate, Time, Fees) VALUES (@Batch_id, @Dtype, @Ins_id, @Sdate, @Edate, @Time, @Fees)"
            Dim cmd As New SqlCommand(query, conn)

            cmd.Parameters.AddWithValue("@Batch_id", TxtBatchID.Text)
            cmd.Parameters.AddWithValue("@Dtype", TxtDanceType.Text)
            cmd.Parameters.AddWithValue("@Ins_id", TxtInstructorID.Text)
            cmd.Parameters.AddWithValue("@Sdate", DtpStartDate.Value)
            cmd.Parameters.AddWithValue("@Edate", DtpEndDate.Value)
            cmd.Parameters.AddWithValue("@Time", TxtTime.Text)
            cmd.Parameters.AddWithValue("@Fees", TxtFees.Text)

            conn.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Batch added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LoadBatches()
        End Using
    End Sub

    Private Sub BtnDeleteBatch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnDeleteBatch.Click
        If DataGridViewBatches.SelectedRows.Count > 0 Then
            Dim batchID As String = DataGridViewBatches.SelectedRows(0).Cells("Batch_id").Value.ToString()

            Using conn As New SqlConnection(connectionString)
                Dim query As String = "DELETE FROM Batchsch WHERE Batch_id = @Batch_id"
                Dim cmd As New SqlCommand(query, conn)

                cmd.Parameters.AddWithValue("@Batch_id", batchID)

                conn.Open()
                cmd.ExecuteNonQuery()
                MessageBox.Show("Batch deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LoadBatches()
            End Using
        Else
            MessageBox.Show("Please select a batch to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub BtnUpdateBatch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnUpdateBatch.Click
        If DataGridViewBatches.SelectedRows.Count > 0 Then
            Dim batchID As String = DataGridViewBatches.SelectedRows(0).Cells("Batch_id").Value.ToString()

            Using conn As New SqlConnection(connectionString)
                Dim query As String = "UPDATE Batchsch SET Dtype = @Dtype, Ins_id = @Ins_id, Sdate = @Sdate, Edate = @Edate, Time = @Time, Fees = @Fees WHERE Batch_id = @Batch_id"
                Dim cmd As New SqlCommand(query, conn)

                cmd.Parameters.AddWithValue("@Batch_id", batchID)
                cmd.Parameters.AddWithValue("@Dtype", TxtDanceType.Text)
                cmd.Parameters.AddWithValue("@Ins_id", TxtInstructorID.Text)
                cmd.Parameters.AddWithValue("@Sdate", DtpStartDate.Value)
                cmd.Parameters.AddWithValue("@Edate", DtpEndDate.Value)
                cmd.Parameters.AddWithValue("@Time", TxtTime.Text)
                cmd.Parameters.AddWithValue("@Fees", TxtFees.Text)

                conn.Open()
                cmd.ExecuteNonQuery()
                MessageBox.Show("Batch updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LoadBatches()
            End Using
        Else
            MessageBox.Show("Please select a batch to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub
    Private Sub BtnBackToDashboard_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnBackToDashboard.Click
        Me.Close() ' Closes the current form and returns to the dashboard
    End Sub
End Class