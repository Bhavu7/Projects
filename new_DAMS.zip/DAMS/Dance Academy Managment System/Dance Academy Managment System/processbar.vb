﻿Public Class processbar

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        pb.Increment(1)
        If pb.Value >= 100 Then
            Me.Hide()
            Dim log As New login()
            log.Show()
            Timer1.Enabled = False
        End If



    End Sub

    Private Sub processbar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub
End Class
