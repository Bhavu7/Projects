﻿Public Class certificate

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Hide()
        Dim back As New dashboard()
        back.Show()
    End Sub

    Private Sub downloadCertificate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles downloadCertificate.Click

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub
End Class