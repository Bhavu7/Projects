﻿Imports System.Data.SqlClient
Public Class batch
    Dim connectionString As String = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\user\Desktop\Nish\DAMS\Dance Academy Managment System\Dance Academy Managment System\DanceManagementSystem.mdf;Integrated Security=True;User Instance=True"
    Private Sub StudentForm_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        LoadData()
    End Sub
    Private Sub LoadData()
        Try
            Using con As New SqlConnection(connectionString)
                con.Open()
                Dim query As String = "SELECT * FROM batchMst"
                Using adapter As New SqlDataAdapter(query, con)
                    Dim dt As New DataTable()
                    adapter.Fill(dt)

                    ' Clear existing columns before setting new data
                    DataGridView1.Columns.Clear()
                    DataGridView1.AutoGenerateColumns = True

                    ' Configure DataGridView properties
                    DataGridView1.RowHeadersVisible = False
                    DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
                    DataGridView1.AllowUserToAddRows = False
                    DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect

                    ' Set the data source
                    DataGridView1.DataSource = dt
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Hide()
        Dim back As New dashboard()
        back.Show()
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            ' Validate dates
            Dim startDateValue As Date
            Dim endDateValue As Date
            Dim timeValue As TimeSpan

            If Not DateTime.TryParse(startDate.Text, startDateValue) Then
                MessageBox.Show("Invalid Start Date. Please enter a valid date in YYYY-MM-DD format.")
                Exit Sub
            End If

            If Not DateTime.TryParse(endDate.Text, endDateValue) Then
                MessageBox.Show("Invalid End Date. Please enter a valid date in YYYY-MM-DD format.")
                Exit Sub
            End If

        ' Use provided time or fallback to system time
            If Not String.IsNullOrWhiteSpace(time.Text) Then
                TimeSpan.TryParse(time.Text, timeValue) ' Parse user input if provided, ignore errors
            End If

            Using con As New SqlConnection(connectionString)
                con.Open()
                Using cmd As New SqlCommand("INSERT INTO batchMst (bid, dtype, iid, sdate, edate, time) VALUES (@bid, @dtype, @iid, @sdate, @edate, @time)", con)
                    cmd.Parameters.AddWithValue("@bid", txtBatchID.Text.Trim())
                    cmd.Parameters.AddWithValue("@dtype", cmbDanceType.Text.Trim())
                    cmd.Parameters.AddWithValue("@iid", txtInstructorID.Text.Trim())
                    cmd.Parameters.AddWithValue("@sdate", startDateValue)
                    cmd.Parameters.AddWithValue("@edate", endDateValue)
                    cmd.Parameters.AddWithValue("@time", timeValue)
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            MessageBox.Show("Record Added Successfully!")
            LoadData()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try

        ' Clear fields
        txtBatchID.Text = ""
        cmbDanceType.Text = ""
        txtInstructorID.Text = ""
        startDate.Text = ""
        endDate.Text = ""
        time.Text = ""
    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            Using con As New SqlConnection(connectionString)
                con.Open()
                Using cmd As New SqlCommand("UPDATE batchMst SET dtype=@dtype, iid=@iid, sdate=@sdate, edate=@edate, time=@time WHERE bid=@bid", con)
                    cmd.Parameters.AddWithValue("@bid", txtBatchID.Text)
                    cmd.Parameters.AddWithValue("@dtype", cmbDanceType.Text)
                    cmd.Parameters.AddWithValue("@iid", txtInstructorID.Text)
                    cmd.Parameters.AddWithValue("@sdate", startDate.Text)
                    cmd.Parameters.AddWithValue("@edate", endDate.Text)
                    cmd.Parameters.AddWithValue("@time", time.Text)
                    cmd.ExecuteNonQuery()
                End Using
            End Using
            MessageBox.Show("Record Updated Successfully!")
            LoadData()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try

        txtBatchID.Text = " "
        cmbDanceType.Text = " "
        txtInstructorID.Text = " "
        startDate.Text = " "
        endDate.Text = " "
        time.Text = " "
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            Using con As New SqlConnection(connectionString)
                con.Open()
                Using cmd As New SqlCommand("DELETE FROM batchMst WHERE bid=@bid", con)
                    cmd.Parameters.AddWithValue("@bid", txtBatchID.Text)
                    cmd.ExecuteNonQuery()
                End Using
            End Using
            MessageBox.Show("Record Deleted Successfully!")
            LoadData()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub
End Class