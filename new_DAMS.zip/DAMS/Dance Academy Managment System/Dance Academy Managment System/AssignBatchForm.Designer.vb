﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AssignBatchForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CmbStudents = New System.Windows.Forms.ComboBox()
        Me.CmbBatches = New System.Windows.Forms.ComboBox()
        Me.BtnAssign = New System.Windows.Forms.Button()
        Me.BtnRemoveAssignment = New System.Windows.Forms.Button()
        Me.BtnBackToDashboard = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(378, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(324, 31)
        Me.Label1.TabIndex = 51
        Me.Label1.Text = "Batch Assignment Form"
        '
        'CmbStudents
        '
        Me.CmbStudents.FormattingEnabled = True
        Me.CmbStudents.ItemHeight = 16
        Me.CmbStudents.Items.AddRange(New Object() {"studentID"})
        Me.CmbStudents.Location = New System.Drawing.Point(332, 169)
        Me.CmbStudents.Margin = New System.Windows.Forms.Padding(6)
        Me.CmbStudents.Name = "CmbStudents"
        Me.CmbStudents.Size = New System.Drawing.Size(121, 24)
        Me.CmbStudents.TabIndex = 52
        '
        'CmbBatches
        '
        Me.CmbBatches.FormattingEnabled = True
        Me.CmbBatches.ItemHeight = 16
        Me.CmbBatches.Items.AddRange(New Object() {"batchID"})
        Me.CmbBatches.Location = New System.Drawing.Point(647, 169)
        Me.CmbBatches.Name = "CmbBatches"
        Me.CmbBatches.Size = New System.Drawing.Size(121, 24)
        Me.CmbBatches.TabIndex = 53
        '
        'BtnAssign
        '
        Me.BtnAssign.Location = New System.Drawing.Point(312, 256)
        Me.BtnAssign.Name = "BtnAssign"
        Me.BtnAssign.Size = New System.Drawing.Size(106, 38)
        Me.BtnAssign.TabIndex = 54
        Me.BtnAssign.Text = "Assign"
        Me.BtnAssign.UseVisualStyleBackColor = True
        '
        'BtnRemoveAssignment
        '
        Me.BtnRemoveAssignment.Location = New System.Drawing.Point(493, 256)
        Me.BtnRemoveAssignment.Name = "BtnRemoveAssignment"
        Me.BtnRemoveAssignment.Size = New System.Drawing.Size(106, 38)
        Me.BtnRemoveAssignment.TabIndex = 55
        Me.BtnRemoveAssignment.Text = "Remove"
        Me.BtnRemoveAssignment.UseVisualStyleBackColor = True
        '
        'BtnBackToDashboard
        '
        Me.BtnBackToDashboard.Location = New System.Drawing.Point(673, 256)
        Me.BtnBackToDashboard.Name = "BtnBackToDashboard"
        Me.BtnBackToDashboard.Size = New System.Drawing.Size(106, 38)
        Me.BtnBackToDashboard.TabIndex = 56
        Me.BtnBackToDashboard.Text = "Back"
        Me.BtnBackToDashboard.UseVisualStyleBackColor = True
        '
        'AssignBatchForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1096, 445)
        Me.Controls.Add(Me.BtnBackToDashboard)
        Me.Controls.Add(Me.BtnRemoveAssignment)
        Me.Controls.Add(Me.BtnAssign)
        Me.Controls.Add(Me.CmbBatches)
        Me.Controls.Add(Me.CmbStudents)
        Me.Controls.Add(Me.Label1)
        Me.Name = "AssignBatchForm"
        Me.Text = "AssignBatchForm"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CmbStudents As System.Windows.Forms.ComboBox
    Friend WithEvents CmbBatches As System.Windows.Forms.ComboBox
    Friend WithEvents BtnAssign As System.Windows.Forms.Button
    Friend WithEvents BtnRemoveAssignment As System.Windows.Forms.Button
    Friend WithEvents BtnBackToDashboard As System.Windows.Forms.Button
End Class
