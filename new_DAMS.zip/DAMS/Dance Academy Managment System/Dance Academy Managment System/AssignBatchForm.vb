﻿' Batch Assignment Form (AssignBatchForm.vb)
Imports System.Data.SqlClient

Public Class AssignBatchForm
    Private connectionString As String = "Server=localhost\SQLEXPRESS;Database=DanceAcademyDB;Integrated Security=True;"

    Private Sub AssignBatchForm_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        LoadStudents()
        LoadBatches()
    End Sub

    Private Sub LoadStudents()
        Using conn As New SqlConnection(connectionString)
            Dim query As String = "SELECT Std_id, Stdfname, Stdlname FROM StudentInfo"
            Dim adapter As New SqlDataAdapter(query, conn)
            Dim table As New DataTable()

            adapter.Fill(table)
            CmbStudents.DataSource = table
            CmbStudents.DisplayMember = "Stdfname"
            CmbStudents.ValueMember = "Std_id"
        End Using
    End Sub

    Private Sub LoadBatches()
        Using conn As New SqlConnection(connectionString)
            Dim query As String = "SELECT Batch_id, Dtype FROM Batchsch"
            Dim adapter As New SqlDataAdapter(query, conn)
            Dim table As New DataTable()

            adapter.Fill(table)
            CmbBatches.DataSource = table
            CmbBatches.DisplayMember = "Dtype"
            CmbBatches.ValueMember = "Batch_id"
        End Using
    End Sub

    Private Sub BtnAssign_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnAssign.Click
        If CmbStudents.SelectedValue IsNot Nothing AndAlso CmbBatches.SelectedValue IsNot Nothing Then
            Dim studentID As String = CmbStudents.SelectedValue.ToString()
            Dim batchID As String = CmbBatches.SelectedValue.ToString()

            Using conn As New SqlConnection(connectionString)
                Dim query As String = "INSERT INTO Assbatch (Std_id, Batch_id) VALUES (@Std_id, @Batch_id)"
                Dim cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@Std_id", studentID)
                cmd.Parameters.AddWithValue("@Batch_id", batchID)

                conn.Open()
                cmd.ExecuteNonQuery()
                MessageBox.Show("Student assigned to batch successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End Using
        Else
            MessageBox.Show("Please select both a student and a batch.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub BtnRemoveAssignment_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnRemoveAssignment.Click
        If CmbStudents.SelectedValue IsNot Nothing AndAlso CmbBatches.SelectedValue IsNot Nothing Then
            Dim studentID As String = CmbStudents.SelectedValue.ToString()
            Dim batchID As String = CmbBatches.SelectedValue.ToString()

            Using conn As New SqlConnection(connectionString)
                Dim query As String = "DELETE FROM Assbatch WHERE Std_id = @Std_id AND Batch_id = @Batch_id"
                Dim cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@Std_id", studentID)
                cmd.Parameters.AddWithValue("@Batch_id", batchID)

                conn.Open()
                Dim rowsAffected As Integer = cmd.ExecuteNonQuery()
                If rowsAffected > 0 Then
                    MessageBox.Show("Assignment removed successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    MessageBox.Show("No such assignment exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End Using
        Else
            MessageBox.Show("Please select both a student and a batch.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub BtnBackToDashboard_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnBackToDashboard.Click
        Me.Close() ' Closes the current form and returns to the dashboard
    End Sub
End Class