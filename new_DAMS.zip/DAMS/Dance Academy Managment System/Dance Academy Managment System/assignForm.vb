﻿Imports System.Data.SqlClient

Public Class assignForm
    ' Database connection string (update this with your database details)
    Dim connectionString As String = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\user\Desktop\Nish\DAMS\Dance Academy Managment System\Dance Academy Managment System\DanceManagementSystem.mdf;Integrated Security=True;User Instance=True"

    Private Sub assignForm_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        PopulateStudentIDs()
        PopulateBatchIDs()
    End Sub

    Private Sub PopulateStudentIDs()
        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()
                Dim query As String = "SELECT sid, sfname FROM studentMst"
                Using command As New SqlCommand(query, connection)
                    Using reader As SqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            ' Add items to the combo box (Student ID and First Name)
                            sid.Items.Add(New KeyValuePair(Of Integer, String)(CInt(reader("sid")), reader("sfname").ToString()))
                        End While
                    End Using
                End Using
            End Using
            ' Bind the combo box to display student names and use the student ID as the value
            sid.DisplayMember = "Value"
            sid.ValueMember = "Key"
        Catch ex As Exception
            MessageBox.Show("Error loading Student IDs: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub PopulateBatchIDs()
        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()
                Dim query As String = "SELECT bid FROM batchMst"
                Using command As New SqlCommand(query, connection)
                    Using reader As SqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            bid.Items.Add(CInt(reader("bid")))
                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading Batch IDs: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub assignDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles assignDetails.Click
        Try
            ' Ensure valid inputs
            If sid.SelectedItem Is Nothing Or bid.SelectedItem Is Nothing Then
                MessageBox.Show("Please select both Student ID and Batch ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Get selected values
            Dim selectedStudentID As Integer = CType(sid.SelectedItem, KeyValuePair(Of Integer, String)).Key
            Dim selectedBatchID As Integer = CInt(bid.SelectedItem)

            ' Insert the assignment into the database
            Using connection As New SqlConnection(connectionString)
                connection.Open()
                Dim insertQuery As String = "INSERT INTO AssignmentMst (sid, bid) VALUES (@sid, @bid)"
                Using command As New SqlCommand(insertQuery, connection)
                    command.Parameters.AddWithValue("@sid", selectedStudentID)
                    command.Parameters.AddWithValue("@bid", selectedBatchID)
                    command.ExecuteNonQuery()
                End Using
            End Using

            ' Refresh the DataGridView
            DisplayAssignments()
        Catch ex As Exception
            MessageBox.Show("Error during assignment: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub DisplayAssignments()
        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()
                Dim query As String = "SELECT a.assignID, s.sfname AS StudentName, b.bid AS BatchID, b.instructorID " & _
                                      "FROM assignmentMst a " & _
                                      "INNER JOIN studentMst s ON a.sid = s.sid " & _
                                      "INNER JOIN batchMst b ON a.bid = b.bid"
                Using command As New SqlCommand(query, connection)
                    Using adapter As New SqlDataAdapter(command)
                        Dim dataTable As New DataTable()
                        adapter.Fill(dataTable)
                        ' Bind data to the DataGridView
                        assignedStudents.DataSource = dataTable
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error displaying assignments: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub BackToDashboard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackToDashboard.Click
        Me.Hide()
        Dim back As New dashboard()
        back.Show()
    End Sub
End Class
