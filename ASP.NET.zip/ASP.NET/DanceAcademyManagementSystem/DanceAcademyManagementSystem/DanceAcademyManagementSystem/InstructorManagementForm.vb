﻿' Instructor Management Form (InstructorManagementForm.vb)
Imports System.Data.SqlClient

Public Class InstructorManagementForm
    Private connectionString As String = "Server=localhost\SQLEXPRESS;Database=DanceAcademyDB;Integrated Security=True;"

    Private Sub InstructorManagementForm_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        LoadInstructors()
    End Sub

    Private Sub LoadInstructors()
        Using conn As New SqlConnection(connectionString)
            Dim query As String = "SELECT * FROM InsInfo"
            Dim adapter As New SqlDataAdapter(query, conn)
            Dim table As New DataTable()

            adapter.Fill(table)
            DataGridViewInstructors.DataSource = table
        End Using
    End Sub

    Private Sub BtnAddInstructor_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnAddInstructor.Click
        Using conn As New SqlConnection(connectionString)
            Dim query As String = "INSERT INTO InsInfo (Ins_id, Insfname, Inslname, Cont_no, Email, Address, Gender, Age, Specialize, Avalbillity) VALUES (@Ins_id, @Insfname, @Inslname, @Cont_no, @Email, @Address, @Gender, @Age, @Specialize, @Avalbillity)"
            Dim cmd As New SqlCommand(query, conn)

            cmd.Parameters.AddWithValue("@Ins_id", TxtInstructorID.Text)
            cmd.Parameters.AddWithValue("@Insfname", TxtFirstName.Text)
            cmd.Parameters.AddWithValue("@Inslname", TxtLastName.Text)
            cmd.Parameters.AddWithValue("@Cont_no", TxtContact.Text)
            cmd.Parameters.AddWithValue("@Email", TxtEmail.Text)
            cmd.Parameters.AddWithValue("@Address", TxtAddress.Text)
            cmd.Parameters.AddWithValue("@Gender", CmbGender.SelectedItem.ToString())
            cmd.Parameters.AddWithValue("@Age", TxtAge.Text)
            cmd.Parameters.AddWithValue("@Specialize", TxtSpecialize.Text)
            cmd.Parameters.AddWithValue("@Avalbillity", TxtAvailability.Text)

            conn.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Instructor added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LoadInstructors()
        End Using
    End Sub

    Private Sub BtnDeleteInstructor_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnDeleteInstructor.Click
        ' Ensure the user has entered an Instructor ID
        If String.IsNullOrWhiteSpace(TxtInstructorID.Text) Then
            MessageBox.Show("Please enter the Instructor ID to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Get the Instructor ID from the text box
        Dim instructorID As String = TxtInstructorID.Text

        Using conn As New SqlConnection(connectionString)
            ' SQL query to delete the instructor by ID
            Dim query As String = "DELETE FROM InsInfo WHERE Ins_id = @Ins_id"
            Dim cmd As New SqlCommand(query, conn)

            ' Add the parameter to prevent SQL injection
            cmd.Parameters.AddWithValue("@Ins_id", instructorID)

            ' Open the connection and execute the query
            conn.Open()
            Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

            ' Provide feedback to the user
            If rowsAffected > 0 Then
                MessageBox.Show("Instructor deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LoadInstructors() ' Refresh the DataGridView to reflect changes
            Else
                MessageBox.Show("Instructor ID not found. Please check and try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End Using
    End Sub

    Private Sub BtnUpdateInstructor_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnUpdateInstructor.Click
        ' Ensure the user has entered an Instructor ID
        If String.IsNullOrWhiteSpace(TxtInstructorID.Text) Then
            MessageBox.Show("Please enter the Instructor ID to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Get the Instructor ID from the text box
        Dim instructorID As String = TxtInstructorID.Text

        Using conn As New SqlConnection(connectionString)
            ' SQL query to update the instructor details
            Dim query As String = "UPDATE InsInfo SET Insfname = @Insfname, Inslname = @Inslname, Cont_no = @Cont_no, Email = @Email, Address = @Address, Gender = @Gender, Age = @Age, Specialize = @Specialize, Avalbillity = @Avalbillity WHERE Ins_id = @Ins_id"
            Dim cmd As New SqlCommand(query, conn)

            ' Add parameters to prevent SQL injection
            cmd.Parameters.AddWithValue("@Ins_id", instructorID)
            cmd.Parameters.AddWithValue("@Insfname", TxtFirstName.Text)
            cmd.Parameters.AddWithValue("@Inslname", TxtLastName.Text)
            cmd.Parameters.AddWithValue("@Cont_no", TxtContact.Text)
            cmd.Parameters.AddWithValue("@Email", TxtEmail.Text)
            cmd.Parameters.AddWithValue("@Address", TxtAddress.Text)
            cmd.Parameters.AddWithValue("@Gender", CmbGender.SelectedItem.ToString())
            cmd.Parameters.AddWithValue("@Age", TxtAge.Text)
            cmd.Parameters.AddWithValue("@Specialize", TxtSpecialize.Text)
            cmd.Parameters.AddWithValue("@Avalbillity", TxtAvailability.Text)

            ' Execute the update query
            conn.Open()
            Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

            ' Provide feedback to the user
            If rowsAffected > 0 Then
                MessageBox.Show("Instructor updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LoadInstructors() ' Refresh the DataGridView to reflect changes
            Else
                MessageBox.Show("Instructor ID not found. Please check and try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End Using
    End Sub


    Private Sub BtnBackToDashboard_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnBackToDashboard.Click
        Me.Close() ' Closes the current form and returns to the dashboard
    End Sub
End Class