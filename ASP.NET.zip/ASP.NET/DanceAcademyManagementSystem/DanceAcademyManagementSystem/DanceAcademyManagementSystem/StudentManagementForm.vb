﻿' Student Management Form (StudentManagementForm.vb)
Imports System.Data.SqlClient

Public Class StudentManagementForm
    Private connectionString As String = "Server=localhost\SQLEXPRESS;Database=DanceAcademyDB;Integrated Security=True;"

    Private Sub StudentManagementForm_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        LoadStudents()
    End Sub
    Private Sub LoadStudents()
        Try
            Using conn As New SqlConnection(connectionString)
                Dim query As String = "SELECT * FROM StudentInfo"
                Dim adapter As New SqlDataAdapter(query, conn)
                Dim table As New DataTable()

                conn.Open()  ' Open the connection explicitly
                adapter.Fill(table)

                ' Check if table has data
                If table.Rows.Count > 0 Then
                    DataGridViewStudents.DataSource = table
                Else
                    MessageBox.Show("No records found", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub BtnAddStudent_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnAddStudent.Click
        Using conn As New SqlConnection(connectionString)
            Dim query As String = "INSERT INTO StudentInfo (Std_id, Stdfname, Stdlname, Cont_no, Email, Address, Gender, Age, DanceType) VALUES (@Std_id, @Stdfname, @Stdlname, @Cont_no, @Email, @Address, @Gender, @Age, @DanceType)"
            Dim cmd As New SqlCommand(query, conn)

            cmd.Parameters.AddWithValue("@Std_id", TxtStudentID.Text)
            cmd.Parameters.AddWithValue("@Stdfname", TxtFirstName.Text)
            cmd.Parameters.AddWithValue("@Stdlname", TxtLastName.Text)
            cmd.Parameters.AddWithValue("@Cont_no", TxtContact.Text)
            cmd.Parameters.AddWithValue("@Email", TxtEmail.Text)
            cmd.Parameters.AddWithValue("@Address", TxtAddress.Text)
            cmd.Parameters.AddWithValue("@Gender", CmbGender.SelectedItem.ToString())
            cmd.Parameters.AddWithValue("@Age", TxtAge.Text)
            cmd.Parameters.AddWithValue("@DanceType", TxtDanceType.Text)

            conn.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Student added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LoadStudents()
        End Using
    End Sub
    Private Sub BtnDeleteStudent_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnDeleteStudent.Click
        If DataGridViewStudents.SelectedRows.Count > 0 Then
            Dim studentID As String = DataGridViewStudents.SelectedRows(0).Cells("Std_id").Value.ToString()

            Using conn As New SqlConnection(connectionString)
                Dim query As String = "DELETE FROM StudentInfo WHERE Std_id = @Std_id"
                Dim cmd As New SqlCommand(query, conn)

                cmd.Parameters.AddWithValue("@Std_id", studentID)

                conn.Open()
                cmd.ExecuteNonQuery()
                MessageBox.Show("Student deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LoadStudents()
            End Using
        Else
            MessageBox.Show("Please select a student to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub BtnUpdateStudent_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnUpdateStudent.Click
        If DataGridViewStudents.SelectedRows.Count > 0 Then
            Dim studentID As String = DataGridViewStudents.SelectedRows(0).Cells("Std_id").Value.ToString()

            Using conn As New SqlConnection(connectionString)
                Dim query As String = "UPDATE StudentInfo SET Stdfname = @Stdfname, Stdlname = @Stdlname, Cont_no = @Cont_no, Email = @Email, Address = @Address, Gender = @Gender, Age = @Age, DanceType = @DanceType WHERE Std_id = @Std_id"
                Dim cmd As New SqlCommand(query, conn)

                cmd.Parameters.AddWithValue("@Std_id", studentID)
                cmd.Parameters.AddWithValue("@Stdfname", TxtFirstName.Text)
                cmd.Parameters.AddWithValue("@Stdlname", TxtLastName.Text)
                cmd.Parameters.AddWithValue("@Cont_no", TxtContact.Text)
                cmd.Parameters.AddWithValue("@Email", TxtEmail.Text)
                cmd.Parameters.AddWithValue("@Address", TxtAddress.Text)
                cmd.Parameters.AddWithValue("@Gender", CmbGender.SelectedItem.ToString())
                cmd.Parameters.AddWithValue("@Age", TxtAge.Text)
                cmd.Parameters.AddWithValue("@DanceType", TxtDanceType.Text)

                conn.Open()
                cmd.ExecuteNonQuery()
                MessageBox.Show("Student updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LoadStudents()
            End Using
        Else
            MessageBox.Show("Please select a student to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub


    Private Sub BtnBackToDashboard_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnBackToDashboard.Click
        Me.Close() ' Closes the current form and returns to the dashboard
    End Sub
End Class