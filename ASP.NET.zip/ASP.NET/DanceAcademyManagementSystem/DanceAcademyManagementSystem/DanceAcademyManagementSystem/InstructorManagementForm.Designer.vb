﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InstructorManagementForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BtnBackToDashboard = New System.Windows.Forms.Button()
        Me.LoadStudents = New System.Windows.Forms.Button()
        Me.BtnDeleteInstructor = New System.Windows.Forms.Button()
        Me.BtnUpdateInstructor = New System.Windows.Forms.Button()
        Me.BtnAddInstructor = New System.Windows.Forms.Button()
        Me.TxtSpecialize = New System.Windows.Forms.TextBox()
        Me.TxtAge = New System.Windows.Forms.TextBox()
        Me.CmbGender = New System.Windows.Forms.ComboBox()
        Me.TxtAddress = New System.Windows.Forms.TextBox()
        Me.TxtEmail = New System.Windows.Forms.TextBox()
        Me.TxtContact = New System.Windows.Forms.TextBox()
        Me.TxtLastName = New System.Windows.Forms.TextBox()
        Me.TxtFirstName = New System.Windows.Forms.TextBox()
        Me.TxtInstructorID = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtAvailability = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.DataGridViewInstructors = New System.Windows.Forms.DataGridView()
        Me.InstID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Fname = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Lname = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.email = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.address = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gender = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.age = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.spez = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Avb = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridViewInstructors, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BtnBackToDashboard
        '
        Me.BtnBackToDashboard.Location = New System.Drawing.Point(720, 412)
        Me.BtnBackToDashboard.Name = "BtnBackToDashboard"
        Me.BtnBackToDashboard.Size = New System.Drawing.Size(205, 33)
        Me.BtnBackToDashboard.TabIndex = 47
        Me.BtnBackToDashboard.Text = "Back"
        Me.BtnBackToDashboard.UseVisualStyleBackColor = True
        '
        'LoadStudents
        '
        Me.LoadStudents.Location = New System.Drawing.Point(720, 344)
        Me.LoadStudents.Name = "LoadStudents"
        Me.LoadStudents.Size = New System.Drawing.Size(205, 33)
        Me.LoadStudents.TabIndex = 46
        Me.LoadStudents.Text = "VIEW INSTRUCTOR"
        Me.LoadStudents.UseVisualStyleBackColor = True
        '
        'BtnDeleteInstructor
        '
        Me.BtnDeleteInstructor.Location = New System.Drawing.Point(720, 278)
        Me.BtnDeleteInstructor.Name = "BtnDeleteInstructor"
        Me.BtnDeleteInstructor.Size = New System.Drawing.Size(205, 33)
        Me.BtnDeleteInstructor.TabIndex = 45
        Me.BtnDeleteInstructor.Text = "DELETE INSTRUCTOR"
        Me.BtnDeleteInstructor.UseVisualStyleBackColor = True
        '
        'BtnUpdateInstructor
        '
        Me.BtnUpdateInstructor.Location = New System.Drawing.Point(720, 209)
        Me.BtnUpdateInstructor.Name = "BtnUpdateInstructor"
        Me.BtnUpdateInstructor.Size = New System.Drawing.Size(205, 33)
        Me.BtnUpdateInstructor.TabIndex = 44
        Me.BtnUpdateInstructor.Text = "UPDATE INSTRUCTOR"
        Me.BtnUpdateInstructor.UseVisualStyleBackColor = True
        '
        'BtnAddInstructor
        '
        Me.BtnAddInstructor.Location = New System.Drawing.Point(720, 135)
        Me.BtnAddInstructor.Name = "BtnAddInstructor"
        Me.BtnAddInstructor.Size = New System.Drawing.Size(205, 33)
        Me.BtnAddInstructor.TabIndex = 43
        Me.BtnAddInstructor.Text = "ADD INSTRUCTOR"
        Me.BtnAddInstructor.UseVisualStyleBackColor = True
        '
        'TxtSpecialize
        '
        Me.TxtSpecialize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtSpecialize.Location = New System.Drawing.Point(288, 410)
        Me.TxtSpecialize.Name = "TxtSpecialize"
        Me.TxtSpecialize.Size = New System.Drawing.Size(100, 22)
        Me.TxtSpecialize.TabIndex = 42
        '
        'TxtAge
        '
        Me.TxtAge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtAge.Location = New System.Drawing.Point(288, 376)
        Me.TxtAge.Name = "TxtAge"
        Me.TxtAge.Size = New System.Drawing.Size(100, 22)
        Me.TxtAge.TabIndex = 41
        '
        'CmbGender
        '
        Me.CmbGender.FormattingEnabled = True
        Me.CmbGender.Items.AddRange(New Object() {"Male", "Female"})
        Me.CmbGender.Location = New System.Drawing.Point(288, 341)
        Me.CmbGender.Name = "CmbGender"
        Me.CmbGender.Size = New System.Drawing.Size(121, 24)
        Me.CmbGender.TabIndex = 40
        '
        'TxtAddress
        '
        Me.TxtAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtAddress.Location = New System.Drawing.Point(288, 309)
        Me.TxtAddress.Name = "TxtAddress"
        Me.TxtAddress.Size = New System.Drawing.Size(100, 22)
        Me.TxtAddress.TabIndex = 39
        '
        'TxtEmail
        '
        Me.TxtEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtEmail.Location = New System.Drawing.Point(288, 278)
        Me.TxtEmail.Name = "TxtEmail"
        Me.TxtEmail.Size = New System.Drawing.Size(100, 22)
        Me.TxtEmail.TabIndex = 38
        '
        'TxtContact
        '
        Me.TxtContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtContact.Location = New System.Drawing.Point(288, 243)
        Me.TxtContact.Name = "TxtContact"
        Me.TxtContact.Size = New System.Drawing.Size(100, 22)
        Me.TxtContact.TabIndex = 37
        '
        'TxtLastName
        '
        Me.TxtLastName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtLastName.Location = New System.Drawing.Point(288, 207)
        Me.TxtLastName.Name = "TxtLastName"
        Me.TxtLastName.Size = New System.Drawing.Size(100, 22)
        Me.TxtLastName.TabIndex = 36
        '
        'TxtFirstName
        '
        Me.TxtFirstName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtFirstName.Location = New System.Drawing.Point(288, 173)
        Me.TxtFirstName.Name = "TxtFirstName"
        Me.TxtFirstName.Size = New System.Drawing.Size(100, 22)
        Me.TxtFirstName.TabIndex = 35
        '
        'TxtInstructorID
        '
        Me.TxtInstructorID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtInstructorID.Location = New System.Drawing.Point(288, 142)
        Me.TxtInstructorID.Name = "TxtInstructorID"
        Me.TxtInstructorID.Size = New System.Drawing.Size(100, 22)
        Me.TxtInstructorID.TabIndex = 34
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(176, 412)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(107, 17)
        Me.Label10.TabIndex = 33
        Me.Label10.Text = "Specialization : "
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(176, 378)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(45, 17)
        Me.Label9.TabIndex = 32
        Me.Label9.Text = "Age : "
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(176, 344)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(68, 17)
        Me.Label8.TabIndex = 31
        Me.Label8.Text = "Gender : "
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(176, 311)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(72, 17)
        Me.Label7.TabIndex = 30
        Me.Label7.Text = "Address : "
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(176, 280)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 17)
        Me.Label6.TabIndex = 29
        Me.Label6.Text = "E-mail : "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(176, 245)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(90, 17)
        Me.Label5.TabIndex = 28
        Me.Label5.Text = "Contact No : "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(176, 209)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 17)
        Me.Label4.TabIndex = 27
        Me.Label4.Text = "Last Name : "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(176, 175)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 17)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "First Name : "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(176, 142)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 17)
        Me.Label2.TabIndex = 25
        Me.Label2.Text = "Instructor ID : "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(379, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(314, 31)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "Instructor Management"
        '
        'TxtAvailability
        '
        Me.TxtAvailability.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtAvailability.Location = New System.Drawing.Point(288, 447)
        Me.TxtAvailability.Name = "TxtAvailability"
        Me.TxtAvailability.Size = New System.Drawing.Size(100, 22)
        Me.TxtAvailability.TabIndex = 49
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(176, 449)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(86, 17)
        Me.Label11.TabIndex = 48
        Me.Label11.Text = "Availability : "
        '
        'DataGridViewInstructors
        '
        Me.DataGridViewInstructors.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DataGridViewInstructors.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewInstructors.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.InstID, Me.Fname, Me.Lname, Me.Cno, Me.email, Me.address, Me.gender, Me.age, Me.spez, Me.Avb})
        Me.DataGridViewInstructors.Location = New System.Drawing.Point(38, 565)
        Me.DataGridViewInstructors.Name = "DataGridViewInstructors"
        Me.DataGridViewInstructors.RowTemplate.Height = 24
        Me.DataGridViewInstructors.Size = New System.Drawing.Size(1036, 150)
        Me.DataGridViewInstructors.TabIndex = 50
        '
        'InstID
        '
        Me.InstID.HeaderText = "Instructor ID"
        Me.InstID.Name = "InstID"
        '
        'Fname
        '
        Me.Fname.HeaderText = "First Name"
        Me.Fname.Name = "Fname"
        '
        'Lname
        '
        Me.Lname.HeaderText = "Last Name"
        Me.Lname.Name = "Lname"
        '
        'Cno
        '
        Me.Cno.HeaderText = "Contact No"
        Me.Cno.Name = "Cno"
        '
        'email
        '
        Me.email.HeaderText = "E-mail"
        Me.email.Name = "email"
        '
        'address
        '
        Me.address.HeaderText = "Address"
        Me.address.Name = "address"
        '
        'gender
        '
        Me.gender.HeaderText = "Gender"
        Me.gender.Name = "gender"
        '
        'age
        '
        Me.age.HeaderText = "Age"
        Me.age.Name = "age"
        '
        'spez
        '
        Me.spez.HeaderText = "Specialization"
        Me.spez.Name = "spez"
        '
        'Avb
        '
        Me.Avb.HeaderText = "Availability"
        Me.Avb.Name = "Avb"
        '
        'InstructorManagementForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1101, 798)
        Me.Controls.Add(Me.DataGridViewInstructors)
        Me.Controls.Add(Me.TxtAvailability)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.BtnBackToDashboard)
        Me.Controls.Add(Me.LoadStudents)
        Me.Controls.Add(Me.BtnDeleteInstructor)
        Me.Controls.Add(Me.BtnUpdateInstructor)
        Me.Controls.Add(Me.BtnAddInstructor)
        Me.Controls.Add(Me.TxtSpecialize)
        Me.Controls.Add(Me.TxtAge)
        Me.Controls.Add(Me.CmbGender)
        Me.Controls.Add(Me.TxtAddress)
        Me.Controls.Add(Me.TxtEmail)
        Me.Controls.Add(Me.TxtContact)
        Me.Controls.Add(Me.TxtLastName)
        Me.Controls.Add(Me.TxtFirstName)
        Me.Controls.Add(Me.TxtInstructorID)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "InstructorManagementForm"
        Me.Text = "InstructorManagementForm"
        CType(Me.DataGridViewInstructors, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BtnBackToDashboard As System.Windows.Forms.Button
    Friend WithEvents LoadStudents As System.Windows.Forms.Button
    Friend WithEvents BtnDeleteInstructor As System.Windows.Forms.Button
    Friend WithEvents BtnUpdateInstructor As System.Windows.Forms.Button
    Friend WithEvents BtnAddInstructor As System.Windows.Forms.Button
    Friend WithEvents TxtSpecialize As System.Windows.Forms.TextBox
    Friend WithEvents TxtAge As System.Windows.Forms.TextBox
    Friend WithEvents CmbGender As System.Windows.Forms.ComboBox
    Friend WithEvents TxtAddress As System.Windows.Forms.TextBox
    Friend WithEvents TxtEmail As System.Windows.Forms.TextBox
    Friend WithEvents TxtContact As System.Windows.Forms.TextBox
    Friend WithEvents TxtLastName As System.Windows.Forms.TextBox
    Friend WithEvents TxtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents TxtInstructorID As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtAvailability As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents DataGridViewInstructors As System.Windows.Forms.DataGridView
    Friend WithEvents InstID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Fname As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Lname As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cno As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents email As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents address As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents gender As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents age As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents spez As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Avb As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
