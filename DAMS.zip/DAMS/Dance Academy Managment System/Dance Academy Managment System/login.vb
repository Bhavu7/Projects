﻿Public Class login
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' Get the entered username and password
        Dim username As String = txtUsername.Text
        Dim password As String = txtPassword.Text

        ' Check if the entered credentials are valid
        If username = "nisha@123" And password = "123456" Then
            ' If valid, open the main form
            Me.Hide()
            Dim back As New dashboard()
            back.Show()
        Else
            ' If invalid, display an error message
            MessageBox.Show("Invalid username or password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

    End Sub
End Class