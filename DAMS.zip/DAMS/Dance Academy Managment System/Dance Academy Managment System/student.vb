﻿Imports System.Data.SqlClient
Public Class student
    Dim connectionString As String = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\user\Desktop\Nish\my project\Dance Academy Managment System\Dance Academy Managment System\DanceDB.mdf;Integrated Security=True;User Instance=True"

    Private Sub StudentForm_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        LoadData()
    End Sub
    Private Sub LoadData()
        Try
            Using con As New SqlConnection(connectionString)
                con.Open()
                Dim query As String = "SELECT * FROM studentMst"
                Using adapter As New SqlDataAdapter(query, con)
                    Dim dt As New DataTable()
                    adapter.Fill(dt)

                    ' Clear existing columns before setting new data
                    DataGridView1.Columns.Clear()
                    DataGridView1.AutoGenerateColumns = True

                    ' Configure DataGridView properties
                    DataGridView1.RowHeadersVisible = False
                    DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
                    DataGridView1.AllowUserToAddRows = False
                    DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect

                    ' Set the data source
                    DataGridView1.DataSource = dt
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            Using con As New SqlConnection(connectionString)
                con.Open()
                Using cmd As New SqlCommand("INSERT INTO studentMst (sid, sfname, slname, cno, email, address, gender, age, dtype) VALUES (@sid, @sfname, @slname, @cno, @email, @address, @gender, @age, @dtype)", con)
                    cmd.Parameters.AddWithValue("@sid", txtStudentID.Text)
                    cmd.Parameters.AddWithValue("@sfname", txtFirstName.Text)
                    cmd.Parameters.AddWithValue("@slname", txtLastName.Text)
                    cmd.Parameters.AddWithValue("@cno", txtContactNumber.Text)
                    cmd.Parameters.AddWithValue("@email", txtEmail.Text)
                    cmd.Parameters.AddWithValue("@address", txtAddress.Text)
                    cmd.Parameters.AddWithValue("@gender", cmbGender.Text)
                    cmd.Parameters.AddWithValue("@age", txtAge.Text)
                    cmd.Parameters.AddWithValue("@dtype", cmbDanceType.Text)
                    cmd.ExecuteNonQuery()
                End Using
            End Using
            MessageBox.Show("Record Added Successfully!")
            LoadData()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try

        txtStudentID.Text = "  "
        txtFirstName.Text = " "
        txtLastName.Text = "  "
        txtContactNumber.Text = "  "
        txtEmail.Text = "  "
        txtAddress.Text = "  "
        cmbGender.Text = "  "
        txtAge.Text = "  "
        cmbDanceType.Text = "  "

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Hide()
        Dim back As New dashboard()
        back.Show()
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            Using con As New SqlConnection(connectionString)
                con.Open()
                Using cmd As New SqlCommand("UPDATE studentMst SET sfname=@sfname, slname=@slname, cno=@cno, email=@email, address=@address, gender=@gender, age=@age, dtype=@dtype WHERE sid=@sid", con)
                    cmd.Parameters.AddWithValue("@sid", txtStudentID.Text)    ' Added this line
                    cmd.Parameters.AddWithValue("@sfname", txtFirstName.Text)
                    cmd.Parameters.AddWithValue("@slname", txtLastName.Text)
                    cmd.Parameters.AddWithValue("@cno", txtContactNumber.Text)
                    cmd.Parameters.AddWithValue("@email", txtEmail.Text)
                    cmd.Parameters.AddWithValue("@address", txtAddress.Text)
                    cmd.Parameters.AddWithValue("@gender", cmbGender.Text)
                    cmd.Parameters.AddWithValue("@age", txtAge.Text)
                    cmd.Parameters.AddWithValue("@dtype", cmbDanceType.Text)
                    cmd.ExecuteNonQuery()
                End Using
                MessageBox.Show("Record Updated Successfully!")
                LoadData()
            End Using
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try

        txtStudentID.Text = ""     ' Changed to empty string
        txtFirstName.Text = ""     ' Changed to empty string
        txtLastName.Text = ""      ' Changed to empty string
        txtContactNumber.Text = "" ' Changed to empty string
        txtEmail.Text = ""        ' Changed to empty string
        txtAddress.Text = ""      ' Changed to empty string
        cmbGender.Text = ""       ' Changed to empty string
        txtAge.Text = ""         ' Changed to empty string
        cmbDanceType.Text = ""   ' Changed to empty string
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            Using con As New SqlConnection(connectionString)
                con.Open()
                Using cmd As New SqlCommand("DELETE FROM studentMst WHERE sid=@sid", con)
                    cmd.Parameters.AddWithValue("@sid", txtStudentID.Text)
                    cmd.ExecuteNonQuery()
                End Using
            End Using
            MessageBox.Show("Record Deleted Successfully!")
            LoadData()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub
End Class