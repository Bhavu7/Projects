﻿Public Class certificate

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Hide()
        Dim back As New dashboard()
        back.Show()
    End Sub
End Class